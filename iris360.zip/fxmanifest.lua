-- fxmanifest.lua
fx_version 'cerulean'
game 'gta5'

author 'IRIS360 Team'
description 'Global & Local Ban System '
version '1.0.0'

server_script 'server.lua'
