local validLicenses = {}
local licenseURL = "https://iris360.se/license22"
local licenseChecked = false
local licenseValid = false

local globalIPBansURL = "https://iris360.se/ipban1"
local globalDiscBansURL = "https://iris360.se/discbans2"
local localIPFile = "ip.txt"       
local localDiscFile = "discord.txt"

local globalIPBans = {}
local globalDiscBans = {}
local localIPBans = {}
local localDiscBans = {}

local function loadLocalBans()
    localIPBans = {}
    localDiscBans = {}

    local ipFileContent = LoadResourceFile(GetCurrentResourceName(), localIPFile)
    if ipFileContent then
        for ip in string.gmatch(ipFileContent, "[^\r\n]+") do
            localIPBans[ip] = true
        end
        print("^2[IRIS360] Loaded local IP bans.^0")
    else
        print("^3[IRIS360] No local IP ban file found (ip.txt).^0")
    end

    local discFileContent = LoadResourceFile(GetCurrentResourceName(), localDiscFile)
    if discFileContent then
        for discID in string.gmatch(discFileContent, "[^\r\n]+") do
            localDiscBans[discID] = true
        end
        print("^2[IRIS360] Loaded local Discord bans.^0")
    else
        print("^3[IRIS360] No local Discord ban file found (discord.txt).^0")
    end
end

local function fetchGlobalBans(callback)
    PerformHttpRequest(globalIPBansURL, function(code, data)
        if code == 200 and data then
            globalIPBans = {}
            for ip in string.gmatch(data, "[^\r\n]+") do
                globalIPBans[ip] = true
            end
            print("^2[IRIS360] Global IP bans loaded.^0")
        else
            print("^1[IRIS360] Failed to fetch global IP bans.^0")
        end
    end)

    PerformHttpRequest(globalDiscBansURL, function(code, data)
        if code == 200 and data then
            globalDiscBans = {}
            for discID in string.gmatch(data, "[^\r\n]+") do
                globalDiscBans[discID] = true
            end
            print("^2[IRIS360] Global Discord bans loaded.^0")
        else
            print("^1[IRIS360] Failed to fetch global Discord bans.^0")
        end

        if callback then callback() end
    end)
end

local function fetchLicenses(callback)
    PerformHttpRequest(licenseURL, function(code, data)
        if code == 200 and data then
            validLicenses = {}
            for line in string.gmatch(data, "[^\r\n]+") do
                validLicenses[line] = true
            end

            local license = GetConvar("iris360_license", "")
            licenseValid = validLicenses[license] == true
            licenseChecked = true

            if licenseValid then
                print("^2[IRIS360] License verified successfully.^0")
            else
                print("^1[IRIS360] Invalid or missing license key. Get a valid one at https://iris360.se^0")
            end
        else
            print("^1[IRIS360] Failed to fetch licenses from server. HTTP code: ".. tostring(code) .."^0")
            licenseChecked = true
            licenseValid = false
        end

        if callback then callback() end
    end)
end

AddEventHandler('onResourceStart', function(resource)
    if resource == GetCurrentResourceName() then
        fetchLicenses(function()
            if not licenseValid then
                print("^1[IRIS360] Stopping resource due to invalid license.^0")
                StopResource(resource)
                return
            end

            loadLocalBans()
            fetchGlobalBans(function()
                print("^2[IRIS360] Global and local bans loaded.^0")
            end)
        end)
    end
end)

AddEventHandler('playerConnecting', function(name, setKickReason, deferrals)
    deferrals.defer()

    if not licenseChecked then
        deferrals.done("Server license is still verifying, please try again in a moment.")
        CancelEvent()
        return
    end

    if not licenseValid then
        deferrals.done("Connection denied: Your server is using an invalid Iris360 license key. Get one at iris360.se or https://discord.gg/zJ5cAjUkXR")
        CancelEvent()
        return
    end

    local src = source
    local ip = GetPlayerEndpoint(src)
    local disc = nil

    for _, id in ipairs(GetPlayerIdentifiers(src)) do
        if string.find(id, "discord:") then
            disc = string.sub(id, 9)
            break
        end
    end

    deferrals.update("Checking Iris360 register for banlist...")

    local waitTime = math.random(15000, 23000)
    Citizen.SetTimeout(waitTime, function()
        if globalIPBans[ip] or localIPBans[ip] then
            deferrals.done("You are globally or locally IP banned by Iris360.")
            CancelEvent()
            return
        end

        if disc and (globalDiscBans[disc] or localDiscBans[disc]) then
            deferrals.done("You are globally or locally Discord banned by Iris360.")
            CancelEvent()
            return
        end

        deferrals.done()
    end)
end)
